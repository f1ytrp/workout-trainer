---
name: Kinetic HUD
colors:
  surface: '#111509'
  surface-dim: '#111509'
  surface-bright: '#363b2d'
  surface-container-lowest: '#0b1005'
  surface-container-low: '#191d11'
  surface-container: '#1d2114'
  surface-container-high: '#272c1e'
  surface-container-highest: '#323728'
  on-surface: '#e0e5d0'
  on-surface-variant: '#c2caae'
  inverse-surface: '#e0e5d0'
  inverse-on-surface: '#2d3224'
  outline: '#8c947a'
  outline-variant: '#424934'
  surface-tint: '#99da00'
  primary: '#ffffff'
  on-primary: '#233600'
  primary-container: '#b1f722'
  on-primary-container: '#4c6f00'
  inverse-primary: '#476800'
  secondary: '#c6c6ca'
  on-secondary: '#2f3034'
  secondary-container: '#4a4b4f'
  on-secondary-container: '#bbbbc0'
  tertiary: '#ffffff'
  on-tertiary: '#312e41'
  tertiary-container: '#e6dff8'
  on-tertiary-container: '#666276'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b1f722'
  primary-fixed-dim: '#99da00'
  on-primary-fixed: '#131f00'
  on-primary-fixed-variant: '#354e00'
  secondary-fixed: '#e2e2e6'
  secondary-fixed-dim: '#c6c6ca'
  on-secondary-fixed: '#1a1c1f'
  on-secondary-fixed-variant: '#45474a'
  tertiary-fixed: '#e6dff8'
  tertiary-fixed-dim: '#c9c3db'
  on-tertiary-fixed: '#1c192b'
  on-tertiary-fixed-variant: '#484458'
  background: '#111509'
  on-background: '#e0e5d0'
  surface-variant: '#323728'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  data-lg:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  data-sm:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  screen_padding: 20px
  gutter: 16px
  card_padding: 24px
---

## Brand & Style
The design system embodies a "High-Performance HUD" aesthetic, tailored for elite fitness tracking and biometric analysis. The brand personality is aggressive, technical, and premium, moving away from soft wellness into the territory of bio-hacking and athletic optimization.

The visual style blends **Glassmorphism** with **Technical Minimalism**. It utilizes deep, "infinite" black voids contrasted against hyper-saturated acid tones. Geometric "HUD" (Heads-Up Display) elements—such as fine linework, measurement nodes, and corner brackets—create a sense of precision and data-density. The interface should feel like an advanced cockpit for the human body, evoking focus, energy, and digital sophistication.

## Colors
This is a **dark-first** system. The palette is anchored by an almost-black charcoal background to maximize the contrast of the primary accent.

- **Primary Accent (Acid Lime):** Used for critical actions, progress indicators, and active muscle groups. It represents energy and "go" states.
- **Surface & Background:** The background is a flat `#050607`. Elevated surfaces use `#0A0C0F` with semi-transparent glass overlays to create depth.
- **Status Colors:** These are slightly desaturated compared to the primary accent to ensure they remain informative without distracting from the core "Acid" brand color.

## Typography
The typographic hierarchy relies on the tension between the geometric, expressive **Space Grotesk** for headings and the functional **Inter** for body text.

**Tabular Numeral Implementation:** For all performance metrics, timers, and heart rate data, use **JetBrains Mono** (or Inter with `tnum` features enabled). This ensures that numbers align vertically in lists and do not "jump" during active count-ups. Use `label-caps` for secondary metadata and HUD-style decorations to maintain a technical, engineered feel.

## Layout & Spacing
The layout uses a **fluid-grid** model based on an 8pt rhythm. While the grid is fluid, it is constrained by a standard 20px safe-area margin on mobile devices.

Content density is high, reflecting a professional data tool. Components should be grouped into logical "clusters" using HUD-style separators (thin lines with terminal nodes) rather than relying solely on whitespace. This allows for a "packed" feel that remains legible. Layouts should prioritize vertical scanning for workout logs and horizontal scrolling for metric cards.

## Elevation & Depth
Depth is created through **Glassmorphism** rather than traditional drop shadows. 

- **Surfaces:** Use a background blur of 16px to 28px. The surface fill is a white tint at 5-12% opacity.
- **Borders:** Every glass surface must have a "inner glow" border—a 1px solid stroke with 15% white opacity to define the edge against the dark background.
- **Interactive Layers:** Active states or "floating" elements (like the bottom nav) should increase blur to 32px and add a subtle primary-color tinted outer glow (e.g., `#B8FF2C` at 10% opacity) to signify a "hovering" or "powered-on" state.

## Shapes
The shape language is a mix of high-radius containers and "Technical Sharpness." 

Main cards and containers use a generous **20px radius** to feel modern and premium. However, interior elements like progress segments or HUD decorators may use sharp 0px or small 4px corners to maintain the technical edge. Interactive controls like buttons and chips are **fully pill-shaped**, creating a clear distinction between "containers" (rectilinear-rounded) and "actions" (pill).

## Components

### Floating Navigation
The bottom navigation is a detached glass dock with a 24px blur. The center "Primary Action" is a circular orb with a heavy radial glow in Acid Lime, appearing to be "docked" into the glass bar.

### Anatomical Body Map
Vector-based human silhouettes in muted charcoal. Selected muscle groups should transition to a solid `#B8FF2C` fill with a subtle "pulsing" animation. Lines connecting labels to body parts should be 1px wide with 2px circular "nodes" at the terminals.

### Data Cards & Gauges
- **Gauges:** Circular and semi-circular progress bars should use a "segmented" stroke rather than a continuous one, mimicking a digital tachometer.
- **Progress Bars:** Use thick, 8px tracks with rounded caps. The "unfilled" portion should be `#1A1D21`.
- **Inputs:** Input fields are "ghost" style—no fill, just a bottom border or a very faint 4% white glass fill, with the label in `label-caps` floating above the field.

### HUD Elements
Use 1px lines as dividers. At the ends of these lines, add a 4x4px square or a small crosshair icon to reinforce the technical theme. Use corner brackets (L-shapes) on high-priority data cards to "frame" the content.